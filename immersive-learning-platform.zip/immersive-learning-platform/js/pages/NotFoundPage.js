export default function NotFoundPage() { const page = document.createElement('div'); page.innerHTML = '<h1>NotFoundPage</h1><p>Content coming soon...</p>'; return page; }
