export default function ReportsPage() { const page = document.createElement('div'); page.innerHTML = '<h1>ReportsPage</h1><p>Content coming soon...</p>'; return page; }
